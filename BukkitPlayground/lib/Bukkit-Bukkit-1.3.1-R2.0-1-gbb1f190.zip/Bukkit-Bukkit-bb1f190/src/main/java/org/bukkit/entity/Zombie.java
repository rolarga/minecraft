package org.bukkit.entity;

/**
 * Represents a Zombie.
 */
public interface Zombie extends Monster {}
