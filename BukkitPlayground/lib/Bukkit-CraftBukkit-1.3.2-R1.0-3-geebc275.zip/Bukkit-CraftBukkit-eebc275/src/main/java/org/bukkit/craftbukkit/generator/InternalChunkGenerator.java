package org.bukkit.craftbukkit.generator;

import net.minecraft.server.IChunkProvider;
import org.bukkit.generator.ChunkGenerator;

public abstract class InternalChunkGenerator extends ChunkGenerator implements IChunkProvider {

}
