package org.bukkit.craftbukkit.generator;

import net.minecraft.server.IChunkProvider;
import org.bukkit.generator.ChunkGenerator;

// Do not implement functions to this class, add to NormalChunkGenerator
public abstract class InternalChunkGenerator extends ChunkGenerator implements IChunkProvider {
}
